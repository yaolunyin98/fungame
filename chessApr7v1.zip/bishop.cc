#include "bishop.h"

Bishop::Bishop(PieceType pt, Colour colour, int value) : Piece(pt, colour,value) {}

