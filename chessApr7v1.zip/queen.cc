#include "queen.h"

Queen::Queen(PieceType pt, Colour colour, int value) : Piece(pt, colour,value) {}

