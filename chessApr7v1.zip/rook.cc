#include "rook.h"

Rook::Rook(PieceType pt, Colour colour,int value) : Piece(pt, colour,value) {}

