#include "level1.h"
using namespace std;

Level1::Level1(PlayerType type, string name, Colour colour): Computer(type, name, colour) {}

