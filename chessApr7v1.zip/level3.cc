#include "level3.h"
using namespace std;

Level3::Level3(PlayerType type, string name, Colour colour): Computer(type, name, colour) {}
