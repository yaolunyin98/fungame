#include "human.h"
#include <string>
using namespace std;

Human::Human(PlayerType type, string name, Colour colour): Player(type, name, colour) {}
